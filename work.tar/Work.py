
# coding: utf-8

# # House Prices: Advanced Regression Techniques
# SweeneyLin 2017/7/10

# ## Preprocessing

# ### Data Analysis

# In[19]:

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats

# In[2]:

df_train = pd.read_csv("train.csv")
df_test = pd.read_csv("test.csv")


# #### deal with data

# In[114]:

def preprocess(raw):
    # features = raw[['OverallQual', 'OverallCond', 'GrLivArea', 'GarageCars', 'TotalBsmtSF', 'FullBath', 'YearBuilt', 'YearRemodAdd', 'Fireplaces', 'BsmtFinSF1', 'WoodDeckSF', 'OpenPorchSF', 'LotArea']]
    # 1. get rid of features loss too much.
    features = raw.drop(['PoolQC', 'MiscFeature', 'Alley', 'Fence', 'FireplaceQu', 'LotFrontage'], axis=1)
    
    # 2. get rid of features do not correlate to SalePrice or same
    features.drop(['LowQualFinSF', 'EnclosedPorch', 'Id', 'MiscVal', 'BsmtHalfBath', 'BsmtFinSF2', '3SsnPorch', 'MoSold', 
                   'PoolArea', 'ScreenPorch', 'BedroomAbvGr', 'BsmtUnfSF', 'BsmtFullBath', 'HalfBath', 'OpenPorchSF',
                   '2ndFlrSF', 'WoodDeckSF', 'Utilities', 'RoofMatl', 'GarageYrBlt',
                   'MasVnrArea'], axis=1, inplace=True)
    
    # 3. fill missing values
    for col in ['GarageQual', 'GarageFinish', 'GarageType']:
        features[col].fillna('NoGar', inplace=True)
    for col in ['GarageCars', 'GarageArea']:
        features[col].fillna(0.0, inplace=True)
        
    for col in ['BsmtCond', 'BsmtExposure', 'BsmtQual', 'BsmtFinType1', 'BsmtFinType2']:
        features[col].fillna('NoBsmt', inplace=True)
    
    for col in ['MasVnrType', 'MSZoning', 'Functional', 'Electrical', 'KitchenQual', 'Exterior1st', 'Exterior2nd', 'SaleType']:
        features[col].fillna(features[col].mode()[0], inplace=True)
        
    for col in ['BsmtFinSF1', 'TotalBsmtSF']:
        features[col].fillna(features[col].mean(), inplace=True)
        
    # 4. catalogical values with int values
    # features['MSSubClass'] = features['MSSubClass'].astype(str)
    # features['OverallQual-str'] = features['OverallQual'].astype(str)
    # features['OverallCond-str'] = features['OverallCond'].astype(str)
    
    # 5. catalogical values to int values
    q_dict = {None: 0, 'NoGar': 0, 'NoBsmt': 0, 'Po': 2, 'No': 2, 'Fa': 4, 'Mn': 4, 'TA': 6, 'Av': 6, 'Gd': 8, 'Ex': 10,
              'Fin': 10, 'RFn': 6, 'Unf': 4}
    for col in ['ExterQual', 'ExterCond', 'BsmtQual', 'BsmtCond', 'HeatingQC', 'KitchenQual', 'GarageQual', 'GarageCond',
                'BsmtExposure', 'GarageFinish']:
        features[col] = features[col].map(q_dict).astype(int)
    q_dict2 = {'GLQ': 10, 'ALQ': 8, 'BLQ': 6, 'Rec': 4, 'LwQ': 2, 'Unf': 0, 'NoBsmt': 0}
    for col in ['BsmtFinType1', 'BsmtFinType2']:
        features[col] = features[col].map(q_dict2).astype(int)
    
    # 6. transformation for some features
    features['GrLivArea'] = np.log(features['GrLivArea'])
    #features['LotArea'] = np.log(features['LotArea'])
    raw['HasBsmt'] = pd.Series(len(raw['TotalBsmtSF']), index=raw.index)
    raw['HasBsmt'] = 0 
    raw.loc[raw['TotalBsmtSF']>0,'HasBsmt'] = 1

    features.loc[raw['HasBsmt']==1,'TotalBsmtSF'] = np.log(raw['TotalBsmtSF'])
    
    features['YearBuilt'] = 2017 - features['YearBuilt']
    features['YearRemodAdd'] = 2017 - features['YearRemodAdd']
    features['YrSold'] = 2017 - features['YrSold']
    
    # 7. build new features from known ones
    features['OverallQual-s2'] = features['OverallQual'] ** 2
    features['OverallQual-s3'] = features['OverallQual'] ** 3
    features['OverallQual-sq'] = np.sqrt(features['OverallQual'])
    
    features['OverallCond-s2'] = features['OverallCond'] ** 2
    features['OverallCond-s3'] = features['OverallCond'] ** 3
    features['OverallCond-sq'] = np.sqrt(features['OverallCond'])
    
    features['OverallPoint'] = features['OverallQual'] * raw['OverallCond']
    
    #for col in ['ExterQual', 'ExterCond', 'BsmtQual', 'BsmtCond', 'HeatingQC', 'KitchenQual', 'GarageQual', 'GarageCond',
    #            'BsmtExposure', 'GarageFinish', 'BsmtFinType1', 'BsmtFinType2']:
    #    features[col+'-s2'] = features[col] ** 2
    #    features[col+'-s3'] = features[col] ** 3
    #    features[col+'-sq'] = np.sqrt(features[col])
        
    for fea in ['Exter', 'Bsmt', 'Garage']:
        features[fea+'Point'] = features[fea+'Qual'] * features[fea+'Cond']
    
    features['YearBuilt-sq'] = np.sqrt(features['YearBuilt'])
    features['YearRemodAdd-sq'] = np.sqrt(features['YearRemodAdd'])
    features['YrSold-sq'] = np.sqrt(features['YrSold'])
    
    features = pd.get_dummies(features)
    
    return features


# In[115]:

raw_train = pd.read_csv("train.csv")
price_train = raw_train.pop('SalePrice')


# In[116]:

raw_test = pd.read_csv("test.csv")


# In[117]:

features_all = preprocess(pd.concat([raw_train, raw_test], keys=['train', 'test']))


# In[118]:

features_train = features_all.loc['train']
features_test = features_all.loc['test']


# ### Model Selection and Training

# #### Define evaluation metric

# In[14]:

from sklearn.metrics import mean_squared_error

def performance_metric(y_true, y_predict):
    score = mean_squared_error(y_true, y_predict)
    return score


# #### Find the best parameters

# In[121]:

from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import make_scorer
from sklearn.grid_search import GridSearchCV
from sklearn.cross_validation import ShuffleSplit

def fit_model(X, y):
    """ Performs grid search over the 'max_depth' parameter for a 
        decision tree regressor trained on the input data [X, y]. """
    
    # Create cross-validation sets from the training data
    cv_sets = ShuffleSplit(X.shape[0], n_iter = 10, test_size = 0.33, random_state = 0)

    # TODO: Create a decision tree regressor object
    regressor = GradientBoostingRegressor(random_state=1)

    # TODO: Create a dictionary for the parameter 'max_depth' with a range from 1 to 10
    params = {'learning_rate' : [0.01, 0.005, 0.0005, 0.0001, 0.00005],
              'n_estimators' : [i for i in range(300, 1000, 50)] + [i for i in range(1000, 10000, 400)] + [i for i in range(10000, 50000, 3000)],
              'max_depth' : [30, 70, 100],
              'subsample' : [1.0, 0.6, 0.2, 0.05]}

    # TODO: Transform 'performance_metric' into a scoring function using 'make_scorer' 
    scoring_fnc = make_scorer(performance_metric)

    # TODO: Create the grid search object
    print ("Grid search begins...")
    grid = GridSearchCV(regressor, params, scoring_fnc, cv = cv_sets, verbose=1)

    # Fit the grid search object to the data to compute the optimal model
    grid = grid.fit(X, y)

    # Return the optimal model after fitting the data
    return grid.best_estimator_


# In[ ]:

price_train = raw_train['SalePrice']
model = fit_model(features_train, price_train)
model.fit(features_train, price_train)

# In[123]:

result =  ("Grid search result:\nlearning_rate = {}\nn_estimators = {}\nmax_depth = {}\nsubsample = {}".format(
        model.get_params()['learning_rate'], 
        model.get_params()['n_estimators'],
        model.get_params()['max_depth'],
        model.get_params()['subsample']))


predictions = model.predict(features_test)


# In[113]:

solution = pd.DataFrame({"id" :raw_test['Id'], "SalePrice":predictions})
solution.to_csv("solution.csv", index=False)

f = open('log.txt', 'w')
f.write(result)
f.close()
